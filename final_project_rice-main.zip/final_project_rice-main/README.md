# final_project_rice
rice
